

print("str")

var lives = 20

lives = 46

print(lives)

var myType: Int = 42

let apple : Bool = true

print(apple)

var peach : String = "mypeaches!!\n. hello"

print(peach)

//uhh okay..












